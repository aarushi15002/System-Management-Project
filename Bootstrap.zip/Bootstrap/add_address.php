<?php
$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="final"; // Database name 
$tbl_name="address"; // Table name 

// Connect to server and select databse.
$conn=mysqli_connect("$host", "$username", "$password", "$db_name")or die("cannot connect"); 

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$firstname=mysqli_real_escape_string($conn, $_POST['firstname']);
$lastname=mysqli_real_escape_string($conn, $_POST['lastname']);
$company=mysqli_real_escape_string($conn, $_POST['company']);
$address=mysqli_real_escape_string($conn, $_POST['address1']);
$city=mysqli_real_escape_string($conn, $_POST['city']);
$state=mysqli_real_escape_string($conn, $_POST['id_state']);
$pincode=mysqli_real_escape_string($conn, $_POST['postcode']);
$country=mysqli_real_escape_string($conn, $_POST['id_country']);
$home_no= $_POST['phone'];
$phone_no= $_POST['phone_mobile'];

$sql = "INSERT INTO $tbl_name (first_name, last_name,company,address,city,state,pincode,country,home_no,phone_no)
VALUES ('$firstname', '$lastname', '$company','$address','$city','$state','$pincode','$country','$home_no','$phone_no')";

$sql="SELECT * FROM address INNER JOIN users ON address.add_id = users.uid";
echo "$sql";
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>