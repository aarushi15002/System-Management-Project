<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="final"; // Database name 
$tbl_name="products"; // Table name 

// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password", "$db_name")or die("cannot connect"); 

//if we got something through $_POST
if (isset($_POST['search'])) {
    // here you would normally include some database connection
    // never trust what user wrote! We must ALWAYS sanitize user input
    $word = mysqli_real_escape_string($con,$_POST['search']);
    $word = htmlentities($word);
    // build your search query to the database
    $sql = "SELECT * FROM $tbl_name";
    // WHERE content LIKE '%" . $word . "%' ORDER BY title LIMIT 10";
    $result=mysqli_query($con,$sql);
    // get results
    while($row = mysqli_fetch_array($result)){
    if(count($row)) {
        $end_result = '';
        foreach($row as $r) {
            $result         = $row['name'];
            $bold           = '<span class="found">' . $word . '</span>';    
            $end_result     .= '<li>' . str_ireplace($word, $bold, $result) . '</li>';            
        }
        echo $end_result;
    } else {
        echo '<li>No results found</li>';
    }
}
}
?>