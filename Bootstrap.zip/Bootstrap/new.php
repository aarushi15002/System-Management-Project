<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="final"; // Database name 
$tbl_name="products"; // Table name 

// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password", "$db_name")or die("cannot connect"); 

$sql="SELECT * FROM $tbl_name";
$result=mysqli_query($con,$sql);

echo "<html>
<head>
<title>handEhub</title>
</head>
<body>";
while($row = mysqli_fetch_array($result)){
echo "<br><br>name :";
echo $row['description']."<br>";  //$row['index'] the index here is a field name
}
"
</body>
</html>
"
?>