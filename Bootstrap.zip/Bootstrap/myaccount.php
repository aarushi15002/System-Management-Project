<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head> 
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/global.css" type="text/css" media="all" />
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/blocksearch.css">
	<link rel="stylesheet" href="css/superfish-modified.css">
	<link rel="stylesheet" href="css/product_list.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<title>handEhub</title>

	<style> 
	@font-face {
	
	  font-family: "Arvo";
	  font-style: normal;
	  font-weight: 400;
	  src: local("Arvo"), url("http://fonts.gstatic.com/s/arvo/v9/J0GYVYTizO1mjpT3aOcSbQ.woff2") format("woff2");
	}
	@font-face {
	  font-family: "FontAwesome";
	  font-style: normal;
	  font-weight: normal;
	  src: url("../fonts/fontawesome-webfont.eot?#iefix&v=4.3.0") format("embedded-opentype"), url("../fonts/fontawesome-webfont.woff2?v=4.3.0") format("woff2"), url("../fonts/fontawesome-webfont.woff?v=4.3.0") format("woff"), url("../fonts/fontawesome-webfont.ttf?v=4.3.0") format("truetype"), url("../fonts/fontawesome-webfont.svg?v=4.3.0#fontawesomeregular") format("svg");
	}
	.email{
		color: #fff;
	}
	.email:hover{
		text-decoration: none;
		color: #fff;
	}
	.info {
		min-height: 344px;
		overflow: hidden;
		background:#f2f2f2 none repeat scroll 0% 0%;
		height: 344px;
		padding-right: 29px;
		padding-left: 29px;
		position: relative;
		width:33.3%;
		float:left;
		display:inline-block;
		border-left: 1px solid rgb(217,217,217);
		padding: 20px 10px 0px 29px;
	}
	.info:first-child{
		border-left: none;
	}
	strong a{
		color: rgb(109,109,109);
	}
	strong a:hover{
		text-decoration: none;
		color: #333;
	}
	.n_but{
		max-width:400px;
		margin-top: 0px;
		margin-bottom: 9px;
		color: #777;
		overflow: hidden;
		padding-bottom: 10px; 
		display: block;
		font: 600 16px/20px "open sans","sans-serif";
		color: #555455;
		text-shadow:0px 1px #fff;
		text-transform: uppercase;
		text-decoration: none;
		position: relative;
		border-width:1px;
		border-style: solid;
		border-color: #CACACA #B7B7B7 #9A9A9A;
		background-size: 100% auto;
		background-image: linear-gradient(#F7F7F7, #EDEDED);
		border-radius: 4px;
		padding: 13px 15px 15px 17px;
	}
	.n_but:hover{
      background: #e7e7e7;
      border-color: #9e9e9e #c2c2c2 #c8c8c8 #c2c2c2;
	}
	</style>

	</head>
	<body style="color:#777;">
		<nav class="navbar navbar-inverse navbar-fixed-top" style="position:relative;">
			<div class="container">
				<div class="text-right" style="display:inline-block;float:right;">
					<button type="button" class="btn btn-default text-right">Contact us</button>
						<button type="button" class="btn btn-default text-right" style="border-right: 1px solid #515151;border-radius: 1px;"><?php echo $_SESSION['uname'] ?></button></div>
							<h5 style="display:inline-block;"><img src="phone.png" style="margin:0px 5px 0px 0px">Call us now : <strong style="color:#fff;">+91 - 7503326767</strong></h5>
			</div>
		</nav>
		<div class="container">
							<div class="row">
							<div class="col-sm-4 clearfix">
								<div id="header_logo">
									<a href="http://handehub.com/" title="handEhub">
										<img class="logo img-responsive" src="http://handehub.com/img/handehub-logo-1444045938.jpg" alt="handEhub" width="370" height="76" style="display:inline-block;" />
									</a>
								</div>
							</div>
								<div class="col-sm-4">
									<center><input style="padding: 13px 60px 13px 13px;height: 45px;background: #FBFBFB none repeat scroll 0% 0%;margin-right: 1px;border:1px solid rgb(212,212,212);display:inline-block;margin-top:30px;width:300px;" placeholder="Search">

									<button type="submit" name="submit_search" class="btn btn-default button-search" style="width:40px;height:46px;margin-top:-3px;margin-left:-5px;">search
									</button></center>
								</div>
							<div class="col-sm-4 clearfix">
								<div id="header_logo">
									<a href="http://handehub.com/" title="handEhub">
										<img class="logo img-responsive" src="http://handehub.com/img/handehub-logo-1444045938.jpg" alt="handEhub" width="370" height="76" style="display:inline-block;" />
									</a>
							</div>
							</div>
							</div>
		</div><br></br>
		<div class="container">
		<ul class="sf-menu clearfix menu-content sf-js-enabled sf-arrows">
			<li><a class="sf-with-ul" href="http://handehub.com/12-materials" title="Materials">Materials</a><ul class="submenu-container clearfix first-in-line-xs" style="display: none;"><li><a href="http://handehub.com/13-polyresin" title="Polyresin">Polyresin</a></li><li><a href="http://handehub.com/14-marble" title="Marble">Marble</a></li><li><a href="http://handehub.com/15-metal" title="Metal">Metal</a></li></ul></li><li><a class="sf-with-ul" href="http://handehub.com/19-showpieces" title="Showpieces">Showpieces</a><ul class="submenu-container clearfix first-in-line-xs" style="display: none;"><li><a href="http://handehub.com/20-metal-showpeice" title="Metal Showpeice">Metal Showpeice</a></li><li><a href="http://handehub.com/21-marble-showpiece-" title="Marble Showpiece ">Marble Showpiece </a></li></ul></li><li><a href="http://handehub.com/16-spiritual-idols" title="Spiritual Idols">Spiritual Idols</a></li>
		</ul>
		</div><br><br>
		<div class="container">
		<!-- Breadcrumb -->
		<div class="breadcrumb clearfix" style="padding:0px 11px;">
		<a class="home" href="http://handehub.com/" title="Return to Home"><i class="icon-home"></i></a>
			<span class="navigation-pipe">&gt;</span>
						My Account
			</div>
		<!-- /Breadcrumb -->
		<div class="n_but"><i class="icon-list-ol" style="color:rgb(253,126,1);font-size:25px; border-right:1px solid rgb(200,191,231);padding-right:10px;"></i><span style="font-family:Open Sans;padding-left:10px;">Order history and details</span></div>
		<div class="n_but"><i class="icon-file-o" style="color:rgb(253,126,1);font-size:25px; border-right:1px solid rgb(200,191,231);padding-right:10px;"></i><span style="font-family:Open Sans;padding-left:10px;">My Credit Slips</span></div>
		<div class="n_but"><i class="icon-building" style="color:rgb(253,126,1);font-size:25px; border-right:1px solid rgb(200,191,231);padding-right:10px;"></i><span style="font-family:Open Sans;padding-left:10px;">My addresses</span></div>
		<div class="n_but"><i class="icon-user" style="color:rgb(253,126,1);font-size:25px; border-right:1px solid rgb(200,191,231);padding-right:10px;"></i><span style="font-family:Open Sans;padding-left:10px;">My personal Details</span></div>
		<br>
		<ul class="footer_links clearfix">
		<li><a class="btn btn-default button button-small" href="http://handehub.com/" title="Home"><span><i class="icon-chevron-left"></i> Home</span></a></li>
		</ul>
		<br><br>
		</div>
		<div class="clearfix;"></div>
		<nav class="navbar navbar-inverse navbar-fixed-bottom" style="min-height:360px;background-color:rgb(51,51,51);margin-top:60px;position:relative !important">
		<div class="container">
		<section class="blockcategories_footer footer-block col-xs-12 col-sm-2" style="line-height:2;">
			<h4 style="margin-top: 50px; font-family: Arvo; color: rgb(255, 255, 255);"><b>Categories</b></h4>	
			<ul>
			<li>
				<a href="#" class="category"><b>Materials</b></a>
			</li>																	
			<li>
				<a href="#" class="category">Showpieces</a>
			</li>
			<li>
				<a href="#" class="category">Spiritual Idols</a>
			</li>							
			</ul>
		</section>
		<section class="footer-block col-xs-12 col-sm-2" id="block_various_links_footer" style="line-height:2;">
			<h4 style="margin-top: 50px; font-family: Arvo; color: rgb(255, 255, 255);"><b>Information</b></h4>
			<ul>
			<li>
				<a href="#" class="category">Specials</a>
			</li>																	
			<li>
				<a href="#" class="category">New Products</a>
			</li>
			<li>
				<a href="#" class="category">Best Sellers</a>
			</li>	
			<li>
				<a href="#" class="category">Contact Us</a>
			</li>																	
			<li>
				<a href="#" class="category">Terms and conditions</a>
			</li>
			<li>
				<a href="#" class="category">About Us</a>
			</li>
			<li>
				<a href="#" class="category">Sitemap</a>
			</li>
			</ul>
		</section>
		<section class="footer-block col-xs-12 col-sm-4" style="line-height:2;">
			<h4 style="margin-top: 50px; font-family: Arvo; color: rgb(255, 255, 255);"><b>My account</b></h4>
			<div class="block_content toggle-footer">
			<ul>
			<li>
				<a href="#" class="category">My orders</a>
			</li>																	
			<li>
				<a href="#" class="category">My credit slips</a>
			</li>
			<li>
				<a href="#" class="category">My addresses</a>
			</li>	
			<li>
				<a href="#" class="category">My personal info</a>
			</li>																	
			<li>
				<a href="#" class="category">My vouchers</a>
			</li>
			</ul>
			</div>
		</section>
		<section id="block_contact_infos" class="footer-block col-xs-12 col-sm-4">
			<div style="border-left:1px solid rgb(110,110,110);height:160px;padding-left:20px;padding-top:-5px;line-height:2.5;font-family:Arvo;">
		        <h4 style="margin-top: 50px;margin-right:20px; font-family: Arvo; color: rgb(255, 255, 255);"><b>Store Information</b></h4>
		        <ul style="font-family:arial;font-size:125%" class="toggle-footer">
		                   	<li>
		            			<i class="icon-map-marker"></i>  handEhub, New Delhi, India 
		                   	</li>
		                  	<li>
		            			<i class="icon-phone"></i>  Call us now: 
		            			<span style="color:#fff;">  7503326767</span>
		            		</li>
		                    <li>
		            			<i class="icon-envelope-alt"></i>  Email: 
		            			<span><a href="mailto:support@handehub.com" class="email">support@handehub.com</a></span>
		            		</li>
		          </ul>
		    </div>
		</section>
		</div>
		<nav class="navbar navbar-inverse" style="min-height:70px;background-color:rgb(63,63,63);bottom:357px;border-radius:0px">
		<div class="container">
		<div style="font-family: Arvo;font-size:21px;color:#fff;line-height:70px;" class="text-left"><b>Newsletter</b>
		<form style="display:inline-block">
		<input style="line-height:35px;margin-left:25px;height:35px;background-color:rgb(60,60,60);color:#fff;font-size:12px;width:260px;margin-top:15px;padding:0px 0px 0px 10px;" placeholder="Enter your e-mail" type="email">
		</form>
		<div style="font-family: Arvo;font-size:21px;color:#fff;line-height:70px;display:inline-block;float:right" class="text-right"><b>Follow Us</b></div>
		</div>
		</div>
		</nav>
		</nav>
	</body>
</html>