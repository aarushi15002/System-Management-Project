<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="final"; // Database name 
$tbl_name="users"; // Table name 

// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password", "$db_name")or die("cannot connect"); 

// username and password sent from form 
$email=$_POST['email']; 
$password=$_POST['passwd']; 

$email = mysqli_real_escape_string($con,$_POST['email']);
$password = mysqli_real_escape_string($con,$_POST['passwd']);
// To protect MySQL injection (more detail about MySQL injection)

$sql="SELECT * FROM $tbl_name WHERE email='$email' and password='$password'";
$result=mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1){

// Register $myusername, $mypassword and redirect to file "login_success.php"
session_start();
$_SESSION['uname']=$row['first_name'];
$_SESSION['email'] = $email;
$_SESSION['password'] = $password;
$_SESSION['loggedin'] = true;
echo "Hello!";
header('Location: myaccount.php');
}
else
{
	echo "Wrong username/password";
	sleep(2);
	header('Location: login.php');
}

?>