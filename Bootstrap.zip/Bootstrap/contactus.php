<?php
$to      = 'rajan15161@iiitd.ac.in';
$subject = 'handEhub contact us';
$from=$_POST['email'];
$message =  stripslashes($_POST['message'] );
$ref=$_POST['id_order'];
mail($to, $subject, $message, $from,$ref);
?>